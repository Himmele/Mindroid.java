var NAVTREE_DATA =
[ [ "mindroid.app", "reference/mindroid/app/package-summary.html", [ [ "Classes", null, [ [ "Service", "reference/mindroid/app/Service.html", null, null ] ]
, null ] ]
, null ], [ "mindroid.content", "reference/mindroid/content/package-summary.html", [ [ "Interfaces", null, [ [ "ServiceConnection", "reference/mindroid/content/ServiceConnection.html", null, null ], [ "SharedPreferences", "reference/mindroid/content/SharedPreferences.html", null, null ], [ "SharedPreferences.Editor", "reference/mindroid/content/SharedPreferences.Editor.html", null, null ] ]
, null ], [ "Classes", null, [ [ "ComponentName", "reference/mindroid/content/ComponentName.html", null, null ], [ "Context", "reference/mindroid/content/Context.html", null, null ], [ "ContextWrapper", "reference/mindroid/content/ContextWrapper.html", null, null ], [ "Intent", "reference/mindroid/content/Intent.html", null, null ] ]
, null ] ]
, null ], [ "mindroid.os", "reference/mindroid/os/package-summary.html", [ [ "Interfaces", null, [ [ "Handler.Callback", "reference/mindroid/os/Handler.Callback.html", null, null ], [ "IBinder", "reference/mindroid/os/IBinder.html", null, null ], [ "IInterface", "reference/mindroid/os/IInterface.html", null, null ] ]
, null ], [ "Classes", null, [ [ "AsyncTask", "reference/mindroid/os/AsyncTask.html", null, null ], [ "Binder", "reference/mindroid/os/Binder.html", null, null ], [ "Bundle", "reference/mindroid/os/Bundle.html", null, null ], [ "Environment", "reference/mindroid/os/Environment.html", null, null ], [ "Executor", "reference/mindroid/os/Executor.html", null, null ], [ "Handler", "reference/mindroid/os/Handler.html", null, null ], [ "HandlerThread", "reference/mindroid/os/HandlerThread.html", null, null ], [ "Looper", "reference/mindroid/os/Looper.html", null, null ], [ "Message", "reference/mindroid/os/Message.html", null, null ], [ "MessageQueue", "reference/mindroid/os/MessageQueue.html", null, null ], [ "SerialExecutor", "reference/mindroid/os/SerialExecutor.html", null, null ], [ "SystemClock", "reference/mindroid/os/SystemClock.html", null, null ], [ "ThreadPoolExecutor", "reference/mindroid/os/ThreadPoolExecutor.html", null, null ] ]
, null ], [ "Exceptions", null, [ [ "RemoteException", "reference/mindroid/os/RemoteException.html", null, null ] ]
, null ] ]
, null ], [ "mindroid.util", "reference/mindroid/util/package-summary.html", [ [ "Classes", null, [ [ "Base64", "reference/mindroid/util/Base64.html", null, null ], [ "Log", "reference/mindroid/util/Log.html", null, null ], [ "Pair", "reference/mindroid/util/Pair.html", null, null ] ]
, null ] ]
, null ], [ "mindroid.util.concurrent", "reference/mindroid/util/concurrent/package-summary.html", [ [ "Classes", null, [ [ "SettableFuture", "reference/mindroid/util/concurrent/SettableFuture.html", null, null ] ]
, null ] ]
, null ] ]

;
